
package com.mycompany.projeto_oo;
public class Medicos extends Pessoas {
    //declarando as variaveis
    private String especialidade;
    private int num_sala;
    private String turno;
    private char sexo;
    //herança
    public Medicos(String nome, int id, String cpf) {
        super(nome, id, cpf);
    }

    //get and set
    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public int getNum_sala() {
        return num_sala;
    }

    public void setNum_sala(int num_sala) {
        this.num_sala = num_sala;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    //construtor
    public Medicos(String especialidade, int num_sala, String turno, char sexo, String nome, int id, String cpf) {
        super(nome, id, cpf);
        this.especialidade = especialidade;
        this.num_sala = num_sala;
        this.turno = turno;
        this.sexo = sexo;
    }
    
    //Função
    public void atender(Pacientes x){
        if(getEspecialidade()=="gastro" && (x.getDoença()!="refluxo" && x.getDoença()!= "diarreia")){
            System.out.println("O medico não tem a especialidade necessária para atender este paciente");
        }else if(getEspecialidade()=="otorrino" && (x.getDoença()!="alergia" && x.getDoença()!= "gripe")){
            System.out.println("O medico não tem a especialidade necessária para atender este paciente");
        }else if(getEspecialidade()=="dermato" && (x.getDoença()!="dermatite" && x.getDoença()!= "coçeira")){
            System.out.println("O medico não tem a especialidade necessária para atender este paciente");
        }
        else{   
            if(x.getSexo()=='M'){
            System.out.println("O Meu nome é "+getNome()+" e irei começar o atendimento do senhor "+x.getNome()+" pela "+getTurno()+" o atendimento será feito na sala "+getNum_sala());
            System.out.println("Posso concluir que o estado do paciente é: "+x.getEstado());  
            if(x.getEstado()=="leve"){
                System.out.println("como seu estado é "+x.getEstado()+" irei receitar apenas um remédio");  
            }else if(x.getEstado()=="mediano"){
                System.out.println("como seu estado é "+x.getEstado()+" irei receitar que o remedio seja aplicado no hospital "); 
            }else{
                System.out.println("como seu estado é "+x.getEstado()+" irei intenar o paciente imediatamente");

            }       
        }else{
            System.out.println("O Meu nome é "+getNome()+" e irei começar o atendimento da senhora "+x.getNome()+" pela "+getTurno()+" o atendimento será feito na sala "+getNum_sala());
            System.out.println("Posso concluir que o estado da paciente é "+x.getEstado());  
            if(x.getEstado()=="leve"){
                System.out.println("como seu estado é "+x.getEstado()+" irei receitar apenas um remédio");  
            }else if(x.getEstado()=="mediano"){
                System.out.println("como seu estado é "+x.getEstado()+" irei receitar que o remedio seja aplicado no hospital"); 
            }else{
                System.out.println("como seu estado é "+x.getEstado()+" irei intenar a paciente imediatamente");

            }       
        }
        }
        System.out.println();
        System.out.println();
        }
}
