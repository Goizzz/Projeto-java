
package com.mycompany.projeto_oo;
public class Consultas_Atendimento {
    public static void main(String[] args ){
    
    //Pacientes
    Pacientes n1 = new Pacientes("grave","refluxo",'M',"Marcelo",111,"05986912522");
    Pacientes n2 = new Pacientes("mediano","diarreia",'F',"Luana",112,"645837216497");
    Pacientes n3 = new Pacientes("leve","alergia",'M',"Gabriel",113,"6458973124");
    Pacientes n4 = new Pacientes("mediano","gripe",'F',"Emylle",114,"64578967542");
    Pacientes n5 = new Pacientes("grave","dermatite",'M',"joão",115,"01264376457");
    Pacientes n6 = new Pacientes("leve","coçeira",'F',"Pietra",116,"64579356412");
   
    //Medicos
    Medicos s1 = new Medicos("gastro",14,"manhã",'M',"Bily",211,"78964352167");
    Medicos s2 = new Medicos("otorrino",15,"tarde",'F',"Laura",212,"79653416715");
    Medicos s3 = new Medicos("dermato",16,"noite",'M',"Jorge",213,"31645973125");
    
    //Enfermeiros
    Enfermeiros f1 = new Enfermeiros ("manhã","A",'F',"Fabiana",311,"98634276537");
    Enfermeiros f2 = new Enfermeiros ("tarde","B",'F',"Ludmila",312,"75463742577");
    Enfermeiros f3 = new Enfermeiros ("noite","C",'M',"Henrique",313,"34579864511");
    
    //Funções
    n1.marcar_consulta();
    n2.marcar_consulta();
    n3.marcar_consulta();
    n4.marcar_consulta();
    n5.marcar_consulta();
    n6.marcar_consulta();
    
    s1.atender(n1);
    s1.atender(n2);
    s2.atender(n3);
    s2.atender(n4);
    s3.atender(n5);
    s3.atender(n6);
    
    f1.aplicar_medic(n2);
    f2.internar(n1);
    f3.aplicar_medic(n4);
    f1.internar(n5);
    }
}

