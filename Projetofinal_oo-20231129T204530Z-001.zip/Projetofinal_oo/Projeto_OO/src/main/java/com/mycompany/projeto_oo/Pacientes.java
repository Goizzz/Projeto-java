
package com.mycompany.projeto_oo;
public class Pacientes extends Pessoas {
    //herança
    public Pacientes(String nome, int id, String cpf) {
        super(nome, id, cpf);
    }
    
    //variavies
    private String estado;
    private String doença;
    private char sexo;
    
    //get and set
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getDoença() {
        return doença;
    }

    public void setDoença(String doença) {
        this.doença = doença;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    //construtor
    public Pacientes(String estado, String doença, char sexo, String nome, int id, String cpf) {
        super(nome, id, cpf);
        this.estado = estado;
        this.doença = doença;
        this.sexo = sexo;
    }
    
    //funções
    public void marcar_consulta(){
    System.out.println("O Meu nome é: "+getNome());
    System.out.println("Pelos meu sintomas acho que estou com: "+getDoença());
    System.out.println("Gostaria de marcar a consulta o quanto antes,meu cpf é: "+getCpf());
    System.out.println();
    }
}
