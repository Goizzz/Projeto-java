
package com.mycompany.projeto_oo;
public class Enfermeiros extends Pessoas {
    //variavies
    private String turno;
    private String leito;
    private char sexo;
    //herança
    public Enfermeiros(String nome, int id, String cpf) {
        super(nome, id, cpf);
    }
    
    //get and set
    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getLeito() {
        return leito;
    }

    public void setLeito(String leito) {
        this.leito = leito;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    //construtor
    public Enfermeiros(String turno, String leito, char sexo, String nome, int id, String cpf) {
        super(nome, id, cpf);
        this.turno = turno;
        this.leito = leito;
        this.sexo = sexo;
    }
    
    //funções
    public void aplicar_medic(Pacientes x){
        if(x.getEstado()!="mediano"){
            System.out.println("O paciente não precisa que a medicação seja aplicada");
        }else{
            if(x.getSexo()=='M'){
                System.out.println("O meu nome é "+getNome()+" e eu irei aplicar a medicação necessária para o senhor "+x.getNome());    
            }else{
                System.out.println("O meu nome é "+getNome()+" e eu irei aplicar a medicação necessária para a senhora "+x.getNome());
            }
            if(x.getDoença()=="refluxo"){
                System.out.println("Para combater o refluxo irei administrar Omeprazol");
            }else if(x.getDoença()=="diarreia"){
                System.out.println("Para combater a diarreia irei administrar Tiorfan");
            }else if(x.getDoença()=="alergia"){
                System.out.println("Para combater a alergia irei administrar Alegra");
            }else if(x.getDoença()=="gripe"){
                System.out.println("Para combater a gripe irei administrar neolefrim");
            }else if(x.getDoença()=="dermatite"){
                System.out.println("Para combater a dermatite irei administrar cimecort");
            }else if(x.getDoença()=="coçeira"){
                System.out.println("Para combater a coçeira irei administrar loratamed");
            }
        }
        System.out.println();
    }
    
    public void internar(Pacientes x){
        if(x.getEstado()!="grave"){
            System.out.println("O paciente não precisa de internação");
        }else{
            if(x.getSexo()=='M'){
                System.out.println("O meu nome é "+getNome()+" e eu irei internar o senhor "+x.getNome()+" no leito "+getLeito());    
            }else{
                System.out.println("O meu nome é "+getNome()+" e eu irei internar a senhora "+x.getNome()+" no leito "+getLeito());
            }
            if(x.getDoença()=="refluxo"){
                System.out.println("Para combater o refluxo irei administrar Omeprazol e haverá um periodo de observação de um dia ");
            }else if(x.getDoença()=="diarreia"){
                System.out.println("Para combater a diarreia irei administrar Tiorfane e haverá um periodo de observação de um dia para evitar desidratação ");
            }else if(x.getDoença()=="alergia"){
                System.out.println("Para combater a alergia irei administrar Alegra e haverá uma bateria de exames para identificar a causa da alergia");
            }else if(x.getDoença()=="gripe"){
                System.out.println("Para combater a gripe irei administrar neolefrim e haverá um periodo de observação com o auxilio de bombas de oxigenio");
            }else if(x.getDoença()=="dermatite"){
                System.out.println("Para combater a dermatite irei administrar cimecort e haverá uma bateria de exames para identificar a causa da dermatite ");
            }else if(x.getDoença()=="coçeira"){
                System.out.println("Para combater a coçeira irei administrar loratamed e haverá um periodo de observação acomapnhado de alguns exames");
            }
        }
        System.out.println("");
    } 
}
    
    

